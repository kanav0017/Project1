********************************************************************
	ZYPOP - HTTPS://ZYPOPWEBTEMPLATES.COM
	FREE WEB TEMPLATES
********************************************************************

This is a free web template by ZyPOP (https://zypopwebtemplates.com)



1. Customizing this template
-----------------------------------------
To change the text, content, links etc. open the index.html and other HTML files in your preferred HTML editor. 

To change the CSS you can find the customisable scss files in the /scss folder .

The variables.scss file can be used to customise custom CSS variables used in this specific template. 

The core.css file can be used to customise the design of this template.

They can then be recompiled into styles.css using your favourite Sass compiler. 



2. Terms of use/Licenses
-----------------------------------------
Any stock photographs used in this template are from http://unsplash.com/

This web template also contains support for Font Awesome. For more information see: http://fontawesome.io/license/

The rest of the template has been released under a Creative Commons Attribution license, this means you can use the template as long as a visible link to ZyPOP (https://zypopwebtemplates.com) remains in the footer.
 
This condition can be waived by purchasing a template license for �8.00 (See 3. Template License in this document)

For more information of the license: http://creativecommons.org/licenses/by/3.0/




3. Template License
-----------------------------------------
The link back to ZyPOP (https://zypopwebtemplates.com) and any other copyright/information relating to ZyPOP (https://zypopwebtemplates.com) can be removed with the purchase of a template license. A license costs �8.00 GBP (Approx $10 USD) per domain and gives the site owner/webmaster the right to remove this information.

To purchase a license or for more information see: http://zypopwebtemplates.com/licensing




4. Other information
-----------------------------------------
Please contact us if you need more information about template licences, use of our templates or other queries -  https://zypopwebtemplates.com/contact
